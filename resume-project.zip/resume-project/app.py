"""
Smart Resume Analyzer & Job Recommendation System
==================================================
Main Flask application.

Routes:
    /                -> landing page
    /register        -> create account
    /login           -> log in
    /logout          -> log out
    /dashboard       -> overview of latest analysis + quick stats
    /upload          -> upload + analyze a resume (GET form / POST process)
    /result/<id>     -> detailed result page for one analysis
    /history         -> list of all past analyses for the logged-in user
"""

import os
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash,
)
from werkzeug.utils import secure_filename

import database
from resume_parser import parse_resume
from analyzer import score_resume, get_improvement_suggestions
from recommender import recommend_jobs

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXTENSIONS = {"pdf", "docx", "doc"}

app = Flask(__name__)
app.secret_key = "capstone-resume-analyzer-secret-key"  # change in production
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
database.init_db()


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def login_required(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)
    return wrapped


# ---------------------------------------------------------------------------
# Public pages
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not name or not email or not password:
            flash("All fields are required.", "danger")
        elif password != confirm:
            flash("Passwords do not match.", "danger")
        elif len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
        else:
            success, message = database.create_user(name, email, password)
            if success:
                flash("Account created. Please log in.", "success")
                return redirect(url_for("login"))
            else:
                flash(message, "danger")

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        user = database.verify_user(email, password)
        if user:
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            flash("Welcome back, {}!".format(user["name"]), "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid email or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


# ---------------------------------------------------------------------------
# Authenticated pages
# ---------------------------------------------------------------------------

@app.route("/dashboard")
@login_required
def dashboard():
    user_id = session["user_id"]
    resumes = database.get_resumes_for_user(user_id)
    latest = resumes[0] if resumes else None
    return render_template("dashboard.html", latest=latest, resume_count=len(resumes))


@app.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    if request.method == "POST":
        file = request.files.get("resume")

        if not file or file.filename == "":
            flash("Please choose a resume file (PDF or DOCX).", "danger")
            return redirect(url_for("upload"))

        if not allowed_file(file.filename):
            flash("Unsupported file type. Please upload a PDF or DOCX file.", "danger")
            return redirect(url_for("upload"))

        filename = secure_filename(file.filename)
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(save_path)

        try:
            parsed_data = parse_resume(save_path)
        except Exception as exc:
            flash("Could not read the resume file: {}".format(exc), "danger")
            return redirect(url_for("upload"))

        score_breakdown = score_resume(parsed_data)
        recommendations = recommend_jobs(parsed_data["skills"], top_n=5)
        suggestions = get_improvement_suggestions(score_breakdown, parsed_data)

        # Store suggestions inside the recommendations payload so they
        # persist alongside the analysis in the database.
        stored_payload = {
            "jobs": recommendations,
            "suggestions": suggestions,
        }

        resume_id = database.save_resume_analysis(
            session["user_id"], filename, parsed_data, score_breakdown, stored_payload
        )

        return redirect(url_for("result", resume_id=resume_id))

    return render_template("upload.html")


@app.route("/result/<int:resume_id>")
@login_required
def result(resume_id):
    analysis = database.get_resume_by_id(resume_id, session["user_id"])
    if not analysis:
        flash("Analysis not found.", "danger")
        return redirect(url_for("dashboard"))

    recommendations = analysis["recommendations"].get("jobs", [])
    suggestions = analysis["recommendations"].get("suggestions", [])

    return render_template(
        "result.html",
        analysis=analysis,
        recommendations=recommendations,
        suggestions=suggestions,
    )


@app.route("/history")
@login_required
def history():
    resumes = database.get_resumes_for_user(session["user_id"])
    return render_template("history.html", resumes=resumes)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
