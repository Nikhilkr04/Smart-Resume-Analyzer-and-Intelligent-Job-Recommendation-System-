"""
Resume Analyzer / Scoring Engine
=================================
Implements the weighted scoring formula from the project blueprint:

    Skills      -> 40
    Experience  -> 20
    Education   -> 10
    Projects    -> 15
    Keywords    -> 15
    -----------------
    Total       -> 100
"""

import re

# ATS-friendly action / impact keywords. Resumes that use these are
# generally considered stronger by Applicant Tracking Systems.
ATS_KEYWORDS = [
    "developed", "designed", "implemented", "managed", "led",
    "created", "built", "improved", "optimized", "analyzed",
    "automated", "deployed", "collaborated", "achieved", "increased",
    "reduced", "tested", "maintained", "integrated", "delivered",
]

# Reference points used to normalise raw counts into the weighted score.
MAX_SKILLS_FOR_FULL_SCORE = 12
MAX_EXPERIENCE_YEARS_FOR_FULL_SCORE = 5
MAX_PROJECTS_FOR_FULL_SCORE = 3
MAX_KEYWORDS_FOR_FULL_SCORE = 8


def _scale(value, max_value, weight):
    """Linearly scale `value` (capped at max_value) onto [0, weight]."""
    if max_value <= 0:
        return 0.0
    ratio = min(value, max_value) / max_value
    return round(ratio * weight, 2)


def count_ats_keywords(text):
    text_lower = text.lower()
    count = 0
    for kw in ATS_KEYWORDS:
        count += len(re.findall(r"\b" + re.escape(kw) + r"\b", text_lower))
    return count


def score_resume(parsed_data):
    """
    Compute the resume score and a breakdown by category.

    parsed_data: dict returned by resume_parser.parse_resume()
    Returns: dict with individual component scores and the total.
    """
    skills_count = len(parsed_data.get("skills", []))
    experience_years = parsed_data.get("experience_years", 0.0)
    education_count = len(parsed_data.get("education", []))
    projects_count = len(parsed_data.get("projects", []))
    keyword_count = count_ats_keywords(parsed_data.get("raw_text", ""))

    skills_score = _scale(skills_count, MAX_SKILLS_FOR_FULL_SCORE, 40)
    experience_score = _scale(experience_years, MAX_EXPERIENCE_YEARS_FOR_FULL_SCORE, 20)
    education_score = 10.0 if education_count > 0 else 0.0
    projects_score = _scale(projects_count, MAX_PROJECTS_FOR_FULL_SCORE, 15)
    keywords_score = _scale(keyword_count, MAX_KEYWORDS_FOR_FULL_SCORE, 15)

    total = round(
        skills_score + experience_score + education_score
        + projects_score + keywords_score,
        2,
    )

    return {
        "skills_score": skills_score,
        "experience_score": experience_score,
        "education_score": education_score,
        "projects_score": projects_score,
        "keywords_score": keywords_score,
        "total_score": total,
        "raw_counts": {
            "skills_count": skills_count,
            "experience_years": experience_years,
            "education_count": education_count,
            "projects_count": projects_count,
            "keyword_count": keyword_count,
        },
    }


def get_improvement_suggestions(score_breakdown, parsed_data):
    """
    Generate plain-language suggestions based on weak score categories.
    """
    suggestions = []

    if score_breakdown["skills_score"] < 25:
        suggestions.append(
            "Add more relevant technical skills to your resume. "
            "Aim to clearly list tools, languages, and frameworks you know."
        )
    if score_breakdown["experience_score"] < 8:
        suggestions.append(
            "Highlight internships, part-time roles, or freelance work "
            "and mention the duration (e.g. '6 months experience')."
        )
    if score_breakdown["education_score"] == 0:
        suggestions.append(
            "Add a clearly labeled Education section with your degree, "
            "institution, and year."
        )
    if score_breakdown["projects_score"] < 10:
        suggestions.append(
            "Add at least 2-3 projects with a short description of what "
            "you built and the technologies used."
        )
    if score_breakdown["keywords_score"] < 8:
        suggestions.append(
            "Use strong action verbs such as 'developed', 'implemented', "
            "'optimized', or 'led' to describe your work and projects."
        )

    if not parsed_data.get("email"):
        suggestions.append("Make sure your email address is clearly visible at the top of your resume.")
    if not parsed_data.get("phone"):
        suggestions.append("Add a contact phone number near the top of your resume.")

    if not suggestions:
        suggestions.append("Great job! Your resume covers all the key sections well.")

    return suggestions
