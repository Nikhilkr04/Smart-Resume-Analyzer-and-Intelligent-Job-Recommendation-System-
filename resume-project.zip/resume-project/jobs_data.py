"""
Sample job roles dataset.
In a production system this would come from a live job-board API or a
database table populated by recruiters. For this capstone project a
static catalogue is used so the recommendation engine has something
meaningful to compare against.
"""

JOBS = [
    {
        "id": 1,
        "title": "Python Developer",
        "skills": ["python", "django", "flask", "sql", "git", "rest api"],
        "description": "Build and maintain server-side applications using Python frameworks.",
    },
    {
        "id": 2,
        "title": "Backend Developer",
        "skills": ["python", "flask", "django", "sql", "mongodb", "rest api", "docker", "git"],
        "description": "Design and implement backend services, APIs, and database models.",
    },
    {
        "id": 3,
        "title": "Data Analyst",
        "skills": ["python", "sql", "pandas", "numpy", "data visualization", "excel", "power bi", "tableau", "statistics"],
        "description": "Analyze datasets, build dashboards, and present business insights.",
    },
    {
        "id": 4,
        "title": "Machine Learning Engineer",
        "skills": ["python", "machine learning", "deep learning", "scikit-learn", "tensorflow", "pandas", "numpy", "sql"],
        "description": "Design, train, and deploy machine learning models into production.",
    },
    {
        "id": 5,
        "title": "Data Scientist",
        "skills": ["python", "machine learning", "statistics", "pandas", "numpy", "data visualization", "sql", "nlp"],
        "description": "Apply statistical and ML techniques to extract insights from data.",
    },
    {
        "id": 6,
        "title": "Full Stack Developer",
        "skills": ["javascript", "react", "node.js", "html", "css", "mongodb", "sql", "git", "rest api"],
        "description": "Develop both client-side and server-side parts of web applications.",
    },
    {
        "id": 7,
        "title": "Frontend Developer",
        "skills": ["html", "css", "javascript", "react", "bootstrap", "tailwind", "redux", "git"],
        "description": "Build responsive, accessible, and performant user interfaces.",
    },
    {
        "id": 8,
        "title": "Java Developer",
        "skills": ["java", "oop", "data structures", "sql", "git", "rest api"],
        "description": "Develop enterprise applications using Java and related frameworks.",
    },
    {
        "id": 9,
        "title": "DevOps Engineer",
        "skills": ["linux", "docker", "kubernetes", "aws", "ci/cd", "jenkins", "git", "terraform"],
        "description": "Automate deployment pipelines and manage cloud infrastructure.",
    },
    {
        "id": 10,
        "title": "Cloud Engineer",
        "skills": ["aws", "azure", "gcp", "docker", "kubernetes", "linux", "terraform"],
        "description": "Design, deploy, and manage scalable cloud infrastructure solutions.",
    },
    {
        "id": 11,
        "title": "Android Developer",
        "skills": ["java", "kotlin", "android", "android development", "sql", "git"],
        "description": "Build and maintain native Android applications.",
    },
    {
        "id": 12,
        "title": "QA / Test Engineer",
        "skills": ["python", "sql", "agile", "scrum", "postman", "git"],
        "description": "Design and execute test plans to ensure software quality.",
    },
    {
        "id": 13,
        "title": "AI/NLP Engineer",
        "skills": ["python", "nlp", "natural language processing", "spacy", "machine learning", "deep learning", "pytorch"],
        "description": "Build language-understanding systems such as chatbots and text analytics tools.",
    },
    {
        "id": 14,
        "title": "Database Administrator",
        "skills": ["sql", "mysql", "postgresql", "oracle", "linux", "redis"],
        "description": "Manage, optimize, and secure database systems.",
    },
    {
        "id": 15,
        "title": "Business Intelligence Analyst",
        "skills": ["sql", "power bi", "tableau", "excel", "data visualization", "statistics"],
        "description": "Turn raw business data into actionable reports and dashboards.",
    },
]
