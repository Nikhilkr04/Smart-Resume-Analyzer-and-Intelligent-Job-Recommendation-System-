"""
Resume Parser
=============
Extracts raw text from PDF / DOCX resumes and then pulls out structured
information from that text:
    - name
    - email
    - phone number
    - skills (matched against skills_data.SKILLS_DB)
    - education
    - years of experience
    - projects

This is a lightweight, dependency-friendly alternative to a full spaCy
pipeline: it uses regex + keyword matching, which is fast, has no model
downloads, and is easy for students to explain in a project viva.
"""

import os
import re

from pypdf import PdfReader
from docx import Document

from skills_data import ALL_SKILLS


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------

def extract_text_from_pdf(filepath):
    text = []
    reader = PdfReader(filepath)
    for page in reader.pages:
        page_text = page.extract_text() or ""
        text.append(page_text)
    return "\n".join(text)


def extract_text_from_docx(filepath):
    doc = Document(filepath)
    paragraphs = [p.text for p in doc.paragraphs]
    # Also pull text out of tables (many resumes use table layouts)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                paragraphs.append(cell.text)
    return "\n".join(paragraphs)


def extract_text(filepath):
    ext = os.path.splitext(filepath)[1].lower()
    if ext == ".pdf":
        return extract_text_from_pdf(filepath)
    elif ext in (".docx", ".doc"):
        return extract_text_from_docx(filepath)
    else:
        raise ValueError("Unsupported file type: {}".format(ext))


# ---------------------------------------------------------------------------
# Field extraction helpers
# ---------------------------------------------------------------------------

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
PHONE_RE = re.compile(r"(?:\+?\d{1,3}[-.\s]?)?\d{10}")

EDUCATION_KEYWORDS = [
    "b.tech", "btech", "bachelor", "m.tech", "mtech", "master",
    "mca", "bca", "msc", "m.sc", "bsc", "b.sc", "phd", "ph.d",
    "diploma", "12th", "10th", "high school", "b.e", "m.e",
    "university", "college", "cgpa", "gpa", "percentage",
]

EXPERIENCE_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years|yrs|year)\s*(?:of)?\s*experience",
    re.IGNORECASE,
)

SECTION_HEADERS = {
    "education": ["education", "academic background", "qualification"],
    "experience": ["experience", "work experience", "employment", "internship"],
    "projects": ["projects", "academic projects", "personal projects"],
    "skills": ["skills", "technical skills", "key skills", "core competencies"],
}


def extract_email(text):
    match = EMAIL_RE.search(text)
    return match.group(0) if match else None


def extract_phone(text):
    match = PHONE_RE.search(text)
    return match.group(0) if match else None


def extract_name(text):
    """
    Heuristic: the candidate's name is usually the first non-empty line
    that doesn't look like an email, phone number, or section header,
    and is short (2-4 words).
    """
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    for line in lines[:8]:
        if EMAIL_RE.search(line) or PHONE_RE.search(line):
            continue
        words = line.split()
        if 1 <= len(words) <= 4 and all(w.replace(".", "").isalpha() for w in words):
            return line.title()
    return "Candidate"


def _split_into_sections(text):
    """
    Split resume text into sections based on common header keywords.
    Returns a dict: section_name -> section_text
    """
    lines = text.splitlines()
    sections = {"_header": []}
    current = "_header"

    for line in lines:
        stripped = line.strip().lower().strip(":")
        matched_section = None
        for section, keywords in SECTION_HEADERS.items():
            for kw in keywords:
                if stripped == kw or (stripped.startswith(kw) and len(stripped) < len(kw) + 15):
                    matched_section = section
                    break
            if matched_section:
                break

        if matched_section:
            current = matched_section
            sections.setdefault(current, [])
            continue

        sections.setdefault(current, [])
        sections[current].append(line)

    return {k: "\n".join(v) for k, v in sections.items()}


def extract_skills(text):
    """
    Match resume text against the master skills database.
    Word-boundary matching keeps "r" or "c" from matching inside other words.
    """
    text_lower = text.lower()
    found = set()
    for skill in ALL_SKILLS:
        pattern = r"(?<![a-zA-Z0-9])" + re.escape(skill) + r"(?![a-zA-Z0-9])"
        if re.search(pattern, text_lower):
            found.add(skill)
    return sorted(found)


def extract_education(text):
    lines = text.splitlines()
    education_lines = []
    for line in lines:
        low = line.lower()
        if any(kw in low for kw in EDUCATION_KEYWORDS):
            cleaned = line.strip()
            if cleaned:
                education_lines.append(cleaned)
    return education_lines[:6]


def extract_experience_years(text):
    match = EXPERIENCE_RE.search(text)
    if match:
        try:
            return float(match.group(1))
        except ValueError:
            return 0.0
    # fall back: count "internship" mentions as a rough signal of experience
    if re.search(r"intern", text, re.IGNORECASE):
        return 0.5
    return 0.0


def extract_projects(sections):
    project_text = sections.get("projects", "")
    if not project_text:
        return []
    lines = [l.strip(" -*•\t") for l in project_text.splitlines() if l.strip()]
    # Treat short lines as project titles
    projects = [l for l in lines if 2 <= len(l.split()) <= 12]
    return projects[:10]


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def parse_resume(filepath):
    """
    Parse a resume file and return a dictionary of extracted fields.
    """
    text = extract_text(filepath)
    sections = _split_into_sections(text)

    data = {
        "raw_text": text,
        "name": extract_name(text),
        "email": extract_email(text),
        "phone": extract_phone(text),
        "skills": extract_skills(text),
        "education": extract_education(text),
        "experience_years": extract_experience_years(text),
        "projects": extract_projects(sections),
    }
    return data
