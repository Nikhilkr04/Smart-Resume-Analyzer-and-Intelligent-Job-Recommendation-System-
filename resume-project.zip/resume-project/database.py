"""
Database layer (SQLite)
========================
Keeps things simple for a capstone project: a single SQLite file
(`database/app.db`) with two tables:

    users   -> id, name, email, password_hash
    resumes -> id, user_id, filename, parsed fields (as JSON), score,
               recommendations (as JSON), created_at

The blueprint suggested MySQL; SQLite is used here so the project runs
immediately with zero external setup. Swapping to MySQL later only
requires changing `get_db_connection()` and the `CREATE TABLE`
statements (the SQL is intentionally close to standard SQL).
"""

import json
import os
import sqlite3
from datetime import datetime

from werkzeug.security import generate_password_hash, check_password_hash

DB_DIR = os.path.join(os.path.dirname(__file__), "database")
DB_PATH = os.path.join(DB_DIR, "app.db")


def get_db_connection():
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS resumes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            filename TEXT,
            candidate_name TEXT,
            email TEXT,
            phone TEXT,
            skills TEXT,
            education TEXT,
            experience_years REAL,
            projects TEXT,
            score_breakdown TEXT,
            recommendations TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)

    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

def create_user(name, email, password):
    conn = get_db_connection()
    try:
        conn.execute(
            "INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, ?)",
            (name, email.lower().strip(), generate_password_hash(password), datetime.utcnow().isoformat()),
        )
        conn.commit()
        return True, "Account created successfully."
    except sqlite3.IntegrityError:
        return False, "An account with this email already exists."
    finally:
        conn.close()


def get_user_by_email(email):
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE email = ?", (email.lower().strip(),)).fetchone()
    conn.close()
    return user


def get_user_by_id(user_id):
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return user


def verify_user(email, password):
    user = get_user_by_email(email)
    if user and check_password_hash(user["password_hash"], password):
        return user
    return None


# ---------------------------------------------------------------------------
# Resumes / analyses
# ---------------------------------------------------------------------------

def save_resume_analysis(user_id, filename, parsed_data, score_breakdown, recommendations):
    conn = get_db_connection()
    conn.execute(
        """
        INSERT INTO resumes (
            user_id, filename, candidate_name, email, phone, skills,
            education, experience_years, projects, score_breakdown,
            recommendations, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            user_id,
            filename,
            parsed_data.get("name"),
            parsed_data.get("email"),
            parsed_data.get("phone"),
            json.dumps(parsed_data.get("skills", [])),
            json.dumps(parsed_data.get("education", [])),
            parsed_data.get("experience_years", 0.0),
            json.dumps(parsed_data.get("projects", [])),
            json.dumps(score_breakdown),
            json.dumps(recommendations),
            datetime.utcnow().isoformat(),
        ),
    )
    conn.commit()
    resume_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.close()
    return resume_id


def _row_to_dict(row):
    if row is None:
        return None
    d = dict(row)
    for field in ("skills", "education", "projects", "score_breakdown", "recommendations"):
        if d.get(field):
            d[field] = json.loads(d[field])
    return d


def get_resume_by_id(resume_id, user_id):
    conn = get_db_connection()
    row = conn.execute(
        "SELECT * FROM resumes WHERE id = ? AND user_id = ?", (resume_id, user_id)
    ).fetchone()
    conn.close()
    return _row_to_dict(row)


def get_resumes_for_user(user_id):
    conn = get_db_connection()
    rows = conn.execute(
        "SELECT * FROM resumes WHERE user_id = ? ORDER BY created_at DESC", (user_id,)
    ).fetchall()
    conn.close()
    return [_row_to_dict(r) for r in rows]


def get_latest_resume_for_user(user_id):
    resumes = get_resumes_for_user(user_id)
    return resumes[0] if resumes else None
