"""
Master skills database.
Each skill maps to a category. Used for:
  - extracting skills from resume text
  - computing skill gap against a job's required skills
"""

SKILLS_DB = {
    # Programming Languages
    "python": "Programming Language",
    "java": "Programming Language",
    "c++": "Programming Language",
    "c": "Programming Language",
    "c#": "Programming Language",
    "javascript": "Programming Language",
    "typescript": "Programming Language",
    "php": "Programming Language",
    "go": "Programming Language",
    "ruby": "Programming Language",
    "kotlin": "Programming Language",
    "swift": "Programming Language",
    "r": "Programming Language",
    "scala": "Programming Language",

    # Web Development
    "html": "Web Development",
    "css": "Web Development",
    "react": "Web Development",
    "react.js": "Web Development",
    "angular": "Web Development",
    "vue": "Web Development",
    "vue.js": "Web Development",
    "node.js": "Web Development",
    "nodejs": "Web Development",
    "express": "Web Development",
    "express.js": "Web Development",
    "django": "Web Development",
    "flask": "Web Development",
    "fastapi": "Web Development",
    "bootstrap": "Web Development",
    "tailwind": "Web Development",
    "jquery": "Web Development",
    "next.js": "Web Development",
    "redux": "Web Development",
    "rest api": "Web Development",
    "graphql": "Web Development",

    # Databases
    "sql": "Database",
    "mysql": "Database",
    "postgresql": "Database",
    "mongodb": "Database",
    "sqlite": "Database",
    "oracle": "Database",
    "redis": "Database",
    "firebase": "Database",
    "cassandra": "Database",

    # Data Science / AI / ML
    "machine learning": "Data Science",
    "deep learning": "Data Science",
    "data analysis": "Data Science",
    "data visualization": "Data Science",
    "pandas": "Data Science",
    "numpy": "Data Science",
    "scikit-learn": "Data Science",
    "tensorflow": "Data Science",
    "keras": "Data Science",
    "pytorch": "Data Science",
    "nlp": "Data Science",
    "natural language processing": "Data Science",
    "computer vision": "Data Science",
    "opencv": "Data Science",
    "spacy": "Data Science",
    "matplotlib": "Data Science",
    "seaborn": "Data Science",
    "power bi": "Data Science",
    "tableau": "Data Science",
    "statistics": "Data Science",

    # Cloud / DevOps
    "aws": "Cloud & DevOps",
    "azure": "Cloud & DevOps",
    "gcp": "Cloud & DevOps",
    "google cloud": "Cloud & DevOps",
    "docker": "Cloud & DevOps",
    "kubernetes": "Cloud & DevOps",
    "jenkins": "Cloud & DevOps",
    "ci/cd": "Cloud & DevOps",
    "terraform": "Cloud & DevOps",
    "linux": "Cloud & DevOps",
    "nginx": "Cloud & DevOps",
    "git": "Cloud & DevOps",
    "github": "Cloud & DevOps",
    "gitlab": "Cloud & DevOps",

    # Tools & Other
    "excel": "Tools",
    "ms office": "Tools",
    "postman": "Tools",
    "jira": "Tools",
    "agile": "Methodology",
    "scrum": "Methodology",
    "data structures": "Computer Science",
    "algorithms": "Computer Science",
    "oop": "Computer Science",
    "object oriented programming": "Computer Science",
    "operating systems": "Computer Science",
    "computer networks": "Computer Science",
    "android": "Mobile Development",
    "android development": "Mobile Development",
    "flutter": "Mobile Development",
    "react native": "Mobile Development",
    "ios development": "Mobile Development",
}

# Sorted longest-first so multi-word skills (e.g. "machine learning")
# are matched before their shorter substrings.
ALL_SKILLS = sorted(SKILLS_DB.keys(), key=len, reverse=True)
