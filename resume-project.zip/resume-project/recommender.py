"""
Job Recommendation Engine
==========================
Uses TF-IDF vectorisation + cosine similarity to compare a candidate's
extracted skills against the required skills of each job in the
catalogue (jobs_data.JOBS), and returns the best matches.

Also provides skill-gap analysis: for a chosen job, which of its
required skills the candidate is missing.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from jobs_data import JOBS


def _skills_to_doc(skills):
    """Turn a list of skills into a space-joined string for TF-IDF."""
    # Replace spaces inside multi-word skills with underscores so
    # "machine learning" is treated as one token, not two.
    return " ".join(s.replace(" ", "_") for s in skills)


def recommend_jobs(user_skills, top_n=5):
    """
    Returns a list of the top_n jobs ranked by cosine similarity between
    the user's skill set and each job's required skills.

    Each result: {job, match_percent, matched_skills, missing_skills}
    """
    if not user_skills:
        return []

    documents = [_skills_to_doc(user_skills)]
    documents += [_skills_to_doc(job["skills"]) for job in JOBS]

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(documents)

    user_vector = tfidf_matrix[0:1]
    job_vectors = tfidf_matrix[1:]

    similarities = cosine_similarity(user_vector, job_vectors)[0]

    results = []
    for job, similarity in zip(JOBS, similarities):
        matched, missing = skill_gap(user_skills, job["skills"])
        results.append({
            "job": job,
            "match_percent": round(float(similarity) * 100, 1),
            "matched_skills": matched,
            "missing_skills": missing,
        })

    results.sort(key=lambda r: r["match_percent"], reverse=True)
    return results[:top_n]


def skill_gap(user_skills, required_skills):
    """
    Compare candidate skills against a job's required skills.
    Returns (matched_skills, missing_skills) as sorted lists.
    """
    user_set = set(s.lower() for s in user_skills)
    required_set = set(s.lower() for s in required_skills)

    matched = sorted(user_set & required_set)
    missing = sorted(required_set - user_set)
    return matched, missing


def get_job_by_id(job_id):
    for job in JOBS:
        if job["id"] == job_id:
            return job
    return None
