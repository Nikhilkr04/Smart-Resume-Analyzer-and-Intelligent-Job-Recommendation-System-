# Smart Resume Analyzer & Intelligent Job Recommendation System

An AI-powered web application built with **Flask** that:

- Parses uploaded resumes (PDF / DOCX)
- Extracts name, email, phone, skills, education, experience, and projects
- Computes a weighted **resume score out of 100**
- Recommends the best-matching **job roles** using TF-IDF + cosine similarity
- Performs **skill-gap analysis** for each recommended role
- Stores analysis history per user (login/registration included)

This matches the project blueprint's modules: Authentication, Resume
Upload, Resume Parsing, Resume Scoring, Job Recommendation, Skill Gap
Analysis, and Dashboard.

---

## 1. Project Structure

```
resume-project/
├── app.py                  # Main Flask app & routes
├── database.py             # SQLite database layer (users + resumes)
├── resume_parser.py         # PDF/DOCX text + field extraction
├── analyzer.py              # Resume scoring engine
├── recommender.py           # Job recommendation + skill gap
├── skills_data.py            # Master skills database
├── jobs_data.py              # Sample job catalogue
├── requirements.txt
├── templates/                # Jinja2 HTML templates
│   ├── base.html
│   ├── index.html
│   ├── register.html
│   ├── login.html
│   ├── dashboard.html
│   ├── upload.html
│   ├── result.html
│   └── history.html
├── static/
│   └── style.css
├── uploads/                  # Created automatically — stores uploaded resumes
└── database/                 # Created automatically — contains app.db (SQLite)
```

> **Note on the database:** The blueprint suggested MySQL. This build uses
> **SQLite** instead so the project runs immediately with zero external
> database setup — perfect for a capstone demo/viva. The SQL is written in
> standard syntax, so migrating to MySQL later mainly means swapping the
> connection in `database.py` and using a MySQL driver (e.g. `mysql-connector-python`).

> **Note on NLP:** The blueprint mentioned spaCy. This build uses a
> lightweight regex + keyword-matching approach (`skills_data.py` +
> `resume_parser.py`) instead of a spaCy model. This avoids large model
> downloads, keeps the app fast, and is easy to explain in a viva. You can
> extend it with spaCy later if you want named-entity recognition.

---

## 2. Prerequisites

- Python 3.9+ installed
- `pip` available

---

## 3. Setup Instructions

### Step 1 — Get the project folder

Copy the entire `resume-project/` folder to your machine.

### Step 2 — Create a virtual environment (recommended)

```bash
cd resume-project
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# macOS / Linux:
source venv/bin/activate
```

### Step 3 — Install dependencies

```bash
pip install -r requirements.txt
```

### Step 4 — Run the application

```bash
python app.py
```

You should see:

```
 * Running on http://127.0.0.1:5000
```

Open **http://127.0.0.1:5000** in your browser.

The SQLite database (`database/app.db`) and `uploads/` folder are created
automatically on first run — no manual database setup needed.

---

## 4. Using the App

1. **Register** a new account (name, email, password).
2. **Log in.**
3. Go to **Analyze Resume** and upload a `.pdf` or `.docx` resume (max 5MB).
4. View your **Resume Report**:
   - Overall score (0–100) with a breakdown across Skills, Experience,
     Education, Projects, and ATS Keywords
   - Detected skills, education, and projects
   - Personalized improvement suggestions
   - Top 5 recommended job roles with a **match %**, the skills you
     already have for that role, and the skills you're **missing**
5. View **History** to see all your past analyses and re-open any report.

---

## 5. How Each Module Works

### Resume Upload & Parsing (`resume_parser.py`)
- `pypdf` extracts text from PDF files.
- `python-docx` extracts text from DOCX files (including tables).
- Regex extracts email and phone number.
- The first short, name-like line is treated as the candidate's name.
- The resume is split into sections (Education, Experience, Projects,
  Skills) using common header keywords.
- Skills are matched against `skills_data.SKILLS_DB`, a curated list of
  100+ technical skills across programming languages, web development,
  databases, data science/AI, cloud/DevOps, and tools.

### Resume Scoring (`analyzer.py`)
Implements the weighted formula from the blueprint:

| Component   | Max Points | How it's measured                                  |
|-------------|-----------:|-----------------------------------------------------|
| Skills      | 40         | Number of matched skills (12+ = full marks)         |
| Experience  | 20         | Years of experience detected (5+ years = full marks)|
| Education   | 10         | Presence of an education section                    |
| Projects    | 15         | Number of projects listed (3+ = full marks)         |
| Keywords    | 15         | Count of ATS action-verb keywords (8+ = full marks) |

The same module generates plain-language **improvement suggestions**
based on which categories scored low.

### Job Recommendation (`recommender.py`)
- Each job in `jobs_data.JOBS` has a list of required skills.
- The candidate's skill list and each job's skill list are vectorized
  with **TF-IDF** and compared using **cosine similarity**.
- The top 5 jobs by similarity are returned, along with which required
  skills the candidate already has (**matched_skills**) and which they're
  missing (**missing_skills**) — this is the skill-gap analysis.

### Authentication & Storage (`database.py`)
- Passwords are hashed with `werkzeug.security`.
- Each analysis (parsed fields + score + recommendations) is stored as a
  row in the `resumes` table, linked to the logged-in user, so it shows
  up in **Dashboard** and **History**.

---

## 6. Extending the Project (Future Scope)

These were listed as future scope in the blueprint and are good next
steps if you want to extend this for a viva / demo:

- **Real job integration**: replace `jobs_data.py` with a live job-board
  API (e.g. fetch postings and their required skills dynamically).
- **Interview chatbot**: add a route that calls an LLM API with the
  candidate's skill gaps to generate practice interview questions.
- **PDF report export**: use a library like `reportlab` to export the
  result page as a downloadable PDF.
- **Admin dashboard**: add an `is_admin` flag to `users` and a route that
  shows aggregate stats across all candidates.
- **MySQL migration**: swap `sqlite3` connections in `database.py` for
  `mysql-connector-python`, and update the `CREATE TABLE` statements'
  data types (`AUTO_INCREMENT`, `VARCHAR`, etc.) as needed.

---

## 7. Troubleshooting

- **"Could not read the resume file" error**: Make sure the file is a
  genuine PDF or DOCX (not a scanned image-only PDF — text must be
  selectable).
- **No skills detected**: Add a clearly labeled "Skills" section listing
  your tools/technologies by name (must match common naming, e.g.
  "Python", "Machine Learning", "React").
- **Port already in use**: change the port in the last line of `app.py`
  (`app.run(..., port=5000)`).
